
<?php
require '../control/searchcontrol.php';

// Instantiate the controller
$controller = new DashboardController();

// Get payment history from the controller
$paymentHistory = $controller->getPaymentHistory();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Taxpayer Dashboard</title>

    <style>
        /* General Styles */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
  background-color: #f9f9f9;
}

.container {
  max-width: 900px;
  margin: 0 auto;
  background-color: #fff;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
}

h1 {
  text-align: center;
  
  margin-bottom: 20px;
}

h2 {
  
  font-size: 1.5em;
  margin-top: 30px;
  margin-bottom: 10px;
}

table {
  width: 100%;
  border-collapse: collapse; /* Ensures borders don't have double lines */
  margin-bottom: 20px;
}

table, th, td {
  border: 1px solid #ddd; /* Applies the border to the entire table, rows, and cells */
}

th, td {
  padding: 15px;
  text-align: left;
}

th {
  background-color: #f2f2f2; /* Light gray background for headers */
}

/* Button Styles */
button {
  cursor: pointer;
}

.view-btn {
  background-color: #4CAF50; /* Green */
  color: white;
  border: none;
  padding: 8px 16px;
  text-align: center;
  font-size: 14px;
  border-radius: 4px;
}

.view-btn:hover {
  background-color: #45a049;
}

.make-payment-btn {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  margin-top: 10px;
}

.make-payment-btn:hover {
  background-color: #45a049;
}

/* Form Styles */
form label {
  font-size: 16px;
  font-weight: bold;
  display: inline-block;
  width: 150px;
}

form input {
  padding: 10px;
  font-size: 14px;
  margin-right: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  width: 200px;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Taxpayer Dashboard</h1>

        <!-- Previous Year Tax Returns Section -->
        <h2>Previous Year Tax Returns</h2>
        <table  boarder="1">
            <thead>
                <tr>
                    <th>Tax Year</th>
                    <th>Status</th>
                    <th>Payment Status</th>
                    <th>View Return</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><button class="view-btn">View</button></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><button class="view-btn">View</button></td>
                </tr>
            </tbody>
        </table>

        <!-- Payment History Section -->
        <h2>Payment History</h2>
        <table>
            <thead>
                <tr>
                    <th>Tax Year</th>
                    <th>Amount Paid</th>
                    <th>Date Paid</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                  <?php
                if ($paymentHistory->num_rows > 0) {
                    // Loop through and display each row
                    while ($row = $paymentHistory->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['taxyear'] . "</td>";
                        echo "<td>" . $row['Amount'] . "</td>";
                        echo "<td>" . $row['time'] . "</td>";  // Assuming 'date_paid' is a field in the database
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No records found</td></tr>";
                }
                ?>
                </tr>
            </tbody>
        </table>

        <!-- Make Payment Section -->
        <h2>Make Payment</h2>
        <form action=" " method="POST">
            <label for="taxyear">Tax Year:</label>
            <input type="text" id="taxyear" name="taxyear" >
            <br><br>
            <label for="Amount">Payment Amount:</label>
            <input type="text" id="Amount" name="Amount" >
            <br><br>
            <button type="submit" name="payment"  value="payment" class="make-payment-btn">Make Payment</button>
        </form>
    </div>
</body>
</html>
