
<?php
include '../control/viewpatientsinfo.php';


?>




<html>
    <head> </head>
<body>

<form action="" method="POST">
    <table>
        <tr>
            <td>
Patient ID:
</Td>
<td>

<input type="text" name="Patientid" id="Patientid"></td>
</tr>
<tr> </tr>
<tr>
    <td> </td>
    <td>
<input type="submit" name="Search"  value="Search"></td>
</tr>
<table>
</form>
</body>
</html>