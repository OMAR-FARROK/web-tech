 
<?php

include '../model/mydb.php';

if(isset($_POST['Search']) ){

$patientid =$_POST['Patientid']; 

$mydb=new mydb(); 
$conobj =$mydb->creatconobject();
$data=$mydb->showorderByid($conobj,"patient",$patientid);


if($data->num_rows > 0){

foreach($data as $row){

   

echo  " Patientid:".$row["PatientID"];
echo " Name :".$row["Name"];
echo " Age :".$row["Age"];
echo " Address :".$row["Address"];
echo " Bloodgroup :".$row["Bloodgp"];
echo " Symptoms:".$row["Symptoms"];
echo " SuggestedTest :".$row["SuggestedTest"];
echo " Email :".$row["Email"]; 
echo " Phone :".$row["PhoneNumber"];

echo "<a href='../view/updatepatientinfo.php?Patientid=".$row["PatientID"]."'>Update </a> ";

echo "<a href='../deletepatientinfo.php?=patientid".$row["PatientID"]."'>Delete</a>";


}



}
else{


echo "no data Found";

 
}

 

}










?>