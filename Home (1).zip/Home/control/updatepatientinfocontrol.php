<?php
include '../model/mydb.php';

$patientid=$_GET['Patientid'];

 



$mydb=new mydb(); 
$conobj =$mydb->creatconobject();
$data=$mydb->showorderByid($conobj,"patient",$patientid );




if($data->num_rows > 0){

    foreach($data as $row){
    
       $patientid=$row["PatientID"];
    
    $Name =$row["Name"];
    $Age =$row["Age"];
    $Address=$row["Address"];
    $Bloodgroup=$row["Bloodgp"];
    $Symptoms=$row["Symptoms"];
    $SuggestedTest=$row["SuggestedTest"];
    $Email=$row["Email"]; 
    $Phone =$row["PhoneNumber"];
    
   
    
    
    }
    
    
    
    }
    else{
    
    
    echo "no data Found";
    
     
    }

    if(isset($_POST["update"]))
    {


        $mydb=new mydb(); 
        $conobj =$mydb->creatconobject();
        $data=$mydb->updatepatientinfo($conobj,"patient",$patientid,$_POST["test"] );
        
        
  if($data===TRUE)
  {
   echo "data Updated";


  }
  else{    echo "not updated"  ; }



    }
    




?>