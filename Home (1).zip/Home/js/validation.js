function formValidation() {
    let isValid = true;

    clearErrorMessages();

  
    isValid &= checkFullName();
    isValid &= checkEmail();
    isValid &= checkPassword();
    isValid &= checkConfirmPassword();
    isValid &= checkPhoneNumber();

    return isValid;
}

function clearErrorMessages() {
    document.getElementById('fullNameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('passwordError').textContent = '';
    document.getElementById('confirmPasswordError').textContent = '';
    document.getElementById('phoneNumberError').textContent = '';
    document.getElementById('successMessage').innerHTML = ''; 
}

function checkFullName() {
    const fullName = document.getElementById('full_name').value;
    if (!fullName.match(/^[A-Za-z\s]+$/) || fullName.trim() === '') {
        document.getElementById('fullNameError').textContent = 'Full Name must contain only alphabets.';
        return false;
    }
    return true;
}

function checkEmail() {
    const email = document.getElementById('email').value;
    if (!email.match(/^[^@\s]+@[^@\s]+\.[^@\s]+$/) || email.trim() === '') {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        return false;
    }
    return true;
}

function checkPassword() {
    const password = document.getElementById('password').value;
    if (password.length < 8) {
        document.getElementById('passwordError').textContent = 'Password must be at least 8 characters.';
        return false;
    }
    return true;
}

function checkConfirmPassword() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match.';
        return false;
    }
    return true;
}

function checkPhoneNumber() {
    const phoneNumber = document.getElementById('phone_number').value;
    if (!phoneNumber.match(/^[0-9]+$/) || phoneNumber.trim() === '') {
        document.getElementById('phoneNumberError').textContent = 'Phone Number must be numeric.';
        return false;
    }
    return true;
}


document.getElementById('registrationForm').addEventListener('submit', function(event) {
    if (!formValidation()) {
        event.preventDefault(); 
    } else {
        document.getElementById('successMessage').innerHTML = 'Form submitted successfully!';
        
    }
});
