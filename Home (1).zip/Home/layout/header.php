<html>
    <head>
<link rel="stylesheet" href="../CSS/style.css">
</head>
    <body>
 
    <div  class="sticky">
          
        <table>
            <tr>
            
   <td> <a href="../view/hello.php">Add Employee</a> </td> <td></td>
   <td>Update Employee </td> </tr>
  <tr>


</table>

</div>



</body>
</html>